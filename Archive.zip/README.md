# amp-orcl-cx-comm-int
Amplience and Oracle CX Commerce Integration

Oracle CX Commerce Extension exposing various Amplience Content Items in the Storefront:
- Amplience Global Settings
- Amplience Banner Widget
- Amplience Banner Slot Widget
- Amplience Card List Widget
